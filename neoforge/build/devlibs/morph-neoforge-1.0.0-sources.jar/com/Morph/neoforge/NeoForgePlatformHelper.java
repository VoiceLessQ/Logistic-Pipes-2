package com.Morph.neoforge;

import java.util.Optional;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import java.util.HashMap;
import java.util.Map;

import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.world.level.material.Fluid;
import net.minecraft.world.level.material.Fluids;
import net.neoforged.neoforge.capabilities.Capabilities;
import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.transfer.fluid.FluidResource;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.transaction.Transaction;

import com.Morph.logisticspipes.platform.IPlatformHelper;
import com.Morph.logisticspipes.power.IPowerProvider;
import com.Morph.logisticspipes.utils.FluidIdentifier;

/**
 * NeoForge implementation of {@link IPlatformHelper}.
 *
 * Item insertion uses the NeoForge 1.21.11 Transfer API:
 *   {@code Capabilities.Item.BLOCK} → {@code ResourceHandler<ItemResource>}
 *
 * Energy lookup stubbed — pipes use {@link com.Morph.logisticspipes.power.FreePowerProvider}
 * which always grants power (config: {@code LPConfig.powerUsageEnabled = false}).
 */
public final class NeoForgePlatformHelper implements IPlatformHelper {

    public static final NeoForgePlatformHelper INSTANCE = new NeoForgePlatformHelper();

    private NeoForgePlatformHelper() {}

    @Override
    public Optional<IPowerProvider> findEnergyProvider(Level level, BlockPos pos, Direction side) {
        // TODO: wire NeoForge energy capability when power integration is needed.
        return Optional.empty();
    }

    @Override
    public ItemStack insertItem(Level level, BlockPos pos, Direction side, ItemStack stack, boolean simulate) {
        if (stack.isEmpty()) return ItemStack.EMPTY;
        BlockPos neighborPos = pos.relative(side);
        ResourceHandler<ItemResource> handler = Capabilities.Item.BLOCK.getCapability(
                level, neighborPos, null, null, side.getOpposite());
        if (handler == null) return stack;
        ItemResource resource = ItemResource.of(stack);
        int toInsert = stack.getCount();
        try (Transaction tx = Transaction.openRoot()) {
            int inserted = handler.insert(resource, toInsert, tx);
            if (!simulate) tx.commit();
            if (inserted <= 0) return stack;
            if (inserted >= toInsert) return ItemStack.EMPTY;
            ItemStack remainder = stack.copy();
            remainder.setCount(toInsert - inserted);
            return remainder;
        }
    }

    @Override
    public ItemStack extractItem(Level level, BlockPos pos, Direction side, ItemStack template, int maxCount, boolean simulate) {
        if (template.isEmpty() || maxCount <= 0) return ItemStack.EMPTY;
        BlockPos neighborPos = pos.relative(side);
        ResourceHandler<ItemResource> handler = Capabilities.Item.BLOCK.getCapability(
                level, neighborPos, null, null, side.getOpposite());
        if (handler == null) return ItemStack.EMPTY;
        ItemResource resource = ItemResource.of(template);
        try (Transaction tx = Transaction.openRoot()) {
            int extracted = handler.extract(resource, maxCount, tx);
            if (extracted <= 0) return ItemStack.EMPTY;
            if (!simulate) tx.commit();
            ItemStack result = template.copy();
            result.setCount(extracted);
            return result;
        }
    }

    @Override
    public Map<Fluid, Integer> getFluidContents(Level level, BlockPos pos, Direction side) {
        BlockPos neighborPos = pos.relative(side);
        ResourceHandler<FluidResource> handler = Capabilities.Fluid.BLOCK.getCapability(
                level, neighborPos, null, null, side.getOpposite());
        if (handler == null) return Map.of();
        Map<Fluid, Integer> result = new HashMap<>();
        // Simulate-extract each registered fluid. NeoForge transactions roll back
        // when closed without commit(), so this is a safe read-only probe.
        for (Fluid fluid : BuiltInRegistries.FLUID) {
            if (fluid == Fluids.EMPTY) continue;
            FluidResource res = FluidResource.of(fluid);
            try (Transaction tx = Transaction.openRoot()) {
                int found = handler.extract(res, Integer.MAX_VALUE / 2, tx);
                if (found > 0) result.put(fluid, found);
                // no commit → rolled back automatically on close
            }
        }
        return result;
    }

    @Override
    public int extractFluid(Level level, BlockPos pos, Direction side, FluidIdentifier fluid, int maxAmountMb) {
        if (maxAmountMb <= 0) return 0;
        BlockPos neighborPos = pos.relative(side);
        ResourceHandler<FluidResource> handler = Capabilities.Fluid.BLOCK.getCapability(
                level, neighborPos, null, null, side.getOpposite());
        if (handler == null) return 0;
        FluidResource resource = FluidResource.of(fluid.fluid);
        try (Transaction tx = Transaction.openRoot()) {
            int extracted = handler.extract(resource, maxAmountMb, tx);
            if (extracted <= 0) return 0;
            tx.commit();
            return extracted;
        }
    }

    @Override
    public int insertFluid(Level level, BlockPos pos, Direction side, FluidIdentifier fluid, int amountMb) {
        if (amountMb <= 0) return 0;
        BlockPos neighborPos = pos.relative(side);
        ResourceHandler<FluidResource> handler = Capabilities.Fluid.BLOCK.getCapability(
                level, neighborPos, null, null, side.getOpposite());
        if (handler == null) return 0;
        FluidResource resource = FluidResource.of(fluid.fluid);
        try (Transaction tx = Transaction.openRoot()) {
            int inserted = handler.insert(resource, amountMb, tx);
            if (inserted <= 0) return 0;
            tx.commit();
            return inserted;
        }
    }
}
