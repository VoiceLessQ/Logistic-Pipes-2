package com.Morph.neoforge.client;

import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;

import com.Morph.ExampleMod;
import com.Morph.logisticspipes.LPClientSetup;

@EventBusSubscriber(modid = ExampleMod.MOD_ID, value = Dist.CLIENT)
public final class ExampleModNeoForgeClient {

    @SubscribeEvent
    public static void onClientSetup(FMLClientSetupEvent event) {
        event.enqueueWork(LPClientSetup::registerScreens);
        event.enqueueWork(LPClientSetup::registerEvents);
        event.enqueueWork(LPClientSetup::registerBlockEntityRenderers);
    }
}
