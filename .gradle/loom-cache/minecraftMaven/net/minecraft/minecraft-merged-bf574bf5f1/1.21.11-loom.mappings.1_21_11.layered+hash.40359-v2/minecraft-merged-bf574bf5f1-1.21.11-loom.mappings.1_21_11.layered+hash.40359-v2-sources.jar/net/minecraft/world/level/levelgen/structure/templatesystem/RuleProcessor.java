package net.minecraft.world.level.levelgen.structure.templatesystem;

import com.google.common.collect.ImmutableList;
import com.mojang.serialization.MapCodec;
import java.util.List;
import net.minecraft.core.BlockPos;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.state.BlockState;
import org.jspecify.annotations.Nullable;

public class RuleProcessor extends StructureProcessor {
	public static final MapCodec<RuleProcessor> CODEC = ProcessorRule.CODEC
		.listOf()
		.fieldOf("rules")
		.xmap(RuleProcessor::new, ruleProcessor -> ruleProcessor.rules);
	private final ImmutableList<ProcessorRule> rules;

	public RuleProcessor(List<? extends ProcessorRule> list) {
		this.rules = ImmutableList.copyOf(list);
	}

	@Nullable
	@Override
	public StructureTemplate.StructureBlockInfo processBlock(
		LevelReader levelReader,
		BlockPos blockPos,
		BlockPos blockPos2,
		StructureTemplate.StructureBlockInfo structureBlockInfo,
		StructureTemplate.StructureBlockInfo structureBlockInfo2,
		StructurePlaceSettings structurePlaceSettings
	) {
		RandomSource randomSource = RandomSource.create(Mth.getSeed(structureBlockInfo2.pos()));
		BlockState blockState = levelReader.getBlockState(structureBlockInfo2.pos());

		for (ProcessorRule processorRule : this.rules) {
			if (processorRule.test(structureBlockInfo2.state(), blockState, structureBlockInfo.pos(), structureBlockInfo2.pos(), blockPos2, randomSource)) {
				return new StructureTemplate.StructureBlockInfo(
					structureBlockInfo2.pos(), processorRule.getOutputState(), processorRule.getOutputTag(randomSource, structureBlockInfo2.nbt())
				);
			}
		}

		return structureBlockInfo2;
	}

	@Override
	protected StructureProcessorType<?> getType() {
		return StructureProcessorType.RULE;
	}
}
