package net.minecraft.world.level.timers;

import com.google.common.collect.HashBasedTable;
import com.google.common.collect.Table;
import com.google.common.primitives.UnsignedLong;
import com.mojang.logging.LogUtils;
import com.mojang.serialization.Dynamic;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;
import java.util.stream.Stream;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.NbtOps;
import net.minecraft.nbt.Tag;
import org.slf4j.Logger;

public class TimerQueue<T> {
	private static final Logger LOGGER = LogUtils.getLogger();
	private static final String CALLBACK_DATA_TAG = "Callback";
	private static final String TIMER_NAME_TAG = "Name";
	private static final String TIMER_TRIGGER_TIME_TAG = "TriggerTime";
	private final TimerCallbacks<T> callbacksRegistry;
	private final Queue<TimerQueue.Event<T>> queue = new PriorityQueue(createComparator());
	private UnsignedLong sequentialId = UnsignedLong.ZERO;
	private final Table<String, Long, TimerQueue.Event<T>> events = HashBasedTable.create();

	private static <T> Comparator<TimerQueue.Event<T>> createComparator() {
		return Comparator.comparingLong(event -> event.triggerTime).thenComparing(event -> event.sequentialId);
	}

	public TimerQueue(TimerCallbacks<T> timerCallbacks, Stream<? extends Dynamic<?>> stream) {
		this(timerCallbacks);
		this.queue.clear();
		this.events.clear();
		this.sequentialId = UnsignedLong.ZERO;
		stream.forEach(dynamic -> {
			Tag tag = dynamic.convert(NbtOps.INSTANCE).getValue();
			if (tag instanceof CompoundTag compoundTag) {
				this.loadEvent(compoundTag);
			} else {
				LOGGER.warn("Invalid format of events: {}", tag);
			}
		});
	}

	public TimerQueue(TimerCallbacks<T> timerCallbacks) {
		this.callbacksRegistry = timerCallbacks;
	}

	public void tick(T object, long l) {
		while (true) {
			TimerQueue.Event<T> event = (TimerQueue.Event<T>)this.queue.peek();
			if (event == null || event.triggerTime > l) {
				return;
			}

			this.queue.remove();
			this.events.remove(event.id, l);
			event.callback.handle(object, this, l);
		}
	}

	public void schedule(String string, long l, TimerCallback<T> timerCallback) {
		if (!this.events.contains(string, l)) {
			this.sequentialId = this.sequentialId.plus(UnsignedLong.ONE);
			TimerQueue.Event<T> event = new TimerQueue.Event<>(l, this.sequentialId, string, timerCallback);
			this.events.put(string, l, event);
			this.queue.add(event);
		}
	}

	public int remove(String string) {
		Collection<TimerQueue.Event<T>> collection = this.events.row(string).values();
		collection.forEach(this.queue::remove);
		int i = collection.size();
		collection.clear();
		return i;
	}

	public Set<String> getEventsIds() {
		return Collections.unmodifiableSet(this.events.rowKeySet());
	}

	private void loadEvent(CompoundTag compoundTag) {
		TimerCallback<T> timerCallback = (TimerCallback<T>)compoundTag.read("Callback", this.callbacksRegistry.codec()).orElse(null);
		if (timerCallback != null) {
			String string = compoundTag.getStringOr("Name", "");
			long l = compoundTag.getLongOr("TriggerTime", 0L);
			this.schedule(string, l, timerCallback);
		}
	}

	private CompoundTag storeEvent(TimerQueue.Event<T> event) {
		CompoundTag compoundTag = new CompoundTag();
		compoundTag.putString("Name", event.id);
		compoundTag.putLong("TriggerTime", event.triggerTime);
		compoundTag.store("Callback", this.callbacksRegistry.codec(), event.callback);
		return compoundTag;
	}

	public ListTag store() {
		ListTag listTag = new ListTag();
		this.queue.stream().sorted(createComparator()).map(this::storeEvent).forEach(listTag::add);
		return listTag;
	}

	public static class Event<T> {
		public final long triggerTime;
		public final UnsignedLong sequentialId;
		public final String id;
		public final TimerCallback<T> callback;

		Event(long l, UnsignedLong unsignedLong, String string, TimerCallback<T> timerCallback) {
			this.triggerTime = l;
			this.sequentialId = unsignedLong;
			this.id = string;
			this.callback = timerCallback;
		}
	}
}
