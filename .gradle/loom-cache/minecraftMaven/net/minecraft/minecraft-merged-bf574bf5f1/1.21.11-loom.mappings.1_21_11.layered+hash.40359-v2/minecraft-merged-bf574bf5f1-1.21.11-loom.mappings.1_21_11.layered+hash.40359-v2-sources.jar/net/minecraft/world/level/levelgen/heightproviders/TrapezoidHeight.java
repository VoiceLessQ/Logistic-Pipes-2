package net.minecraft.world.level.levelgen.heightproviders;

import com.mojang.logging.LogUtils;
import com.mojang.serialization.Codec;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.util.Mth;
import net.minecraft.util.RandomSource;
import net.minecraft.world.level.levelgen.VerticalAnchor;
import net.minecraft.world.level.levelgen.WorldGenerationContext;
import org.slf4j.Logger;

public class TrapezoidHeight extends HeightProvider {
	public static final MapCodec<TrapezoidHeight> CODEC = RecordCodecBuilder.mapCodec(
		instance -> instance.group(
				VerticalAnchor.CODEC.fieldOf("min_inclusive").forGetter(trapezoidHeight -> trapezoidHeight.minInclusive),
				VerticalAnchor.CODEC.fieldOf("max_inclusive").forGetter(trapezoidHeight -> trapezoidHeight.maxInclusive),
				Codec.INT.optionalFieldOf("plateau", 0).forGetter(trapezoidHeight -> trapezoidHeight.plateau)
			)
			.apply(instance, TrapezoidHeight::new)
	);
	private static final Logger LOGGER = LogUtils.getLogger();
	private final VerticalAnchor minInclusive;
	private final VerticalAnchor maxInclusive;
	private final int plateau;

	private TrapezoidHeight(VerticalAnchor verticalAnchor, VerticalAnchor verticalAnchor2, int i) {
		this.minInclusive = verticalAnchor;
		this.maxInclusive = verticalAnchor2;
		this.plateau = i;
	}

	public static TrapezoidHeight of(VerticalAnchor verticalAnchor, VerticalAnchor verticalAnchor2, int i) {
		return new TrapezoidHeight(verticalAnchor, verticalAnchor2, i);
	}

	public static TrapezoidHeight of(VerticalAnchor verticalAnchor, VerticalAnchor verticalAnchor2) {
		return of(verticalAnchor, verticalAnchor2, 0);
	}

	@Override
	public int sample(RandomSource randomSource, WorldGenerationContext worldGenerationContext) {
		int i = this.minInclusive.resolveY(worldGenerationContext);
		int j = this.maxInclusive.resolveY(worldGenerationContext);
		if (i > j) {
			LOGGER.warn("Empty height range: {}", this);
			return i;
		} else {
			int k = j - i;
			if (this.plateau >= k) {
				return Mth.randomBetweenInclusive(randomSource, i, j);
			} else {
				int l = (k - this.plateau) / 2;
				int m = k - l;
				return i + Mth.randomBetweenInclusive(randomSource, 0, m) + Mth.randomBetweenInclusive(randomSource, 0, l);
			}
		}
	}

	@Override
	public HeightProviderType<?> getType() {
		return HeightProviderType.TRAPEZOID;
	}

	public String toString() {
		return this.plateau == 0
			? "triangle (" + this.minInclusive + "-" + this.maxInclusive + ")"
			: "trapezoid(" + this.plateau + ") in [" + this.minInclusive + "-" + this.maxInclusive + "]";
	}
}
